function sayHello(name){
    console.log("Hello "+name);
}

sayHello("Sushant");
global.console.log("From Global");
var message='Hello Message';
message1='Global Hello Message';
console.log(message);
//console.log(global.message); will give error
console.log(global.message1);
console.log("=================\nModule Details\n=================");
console.log(module);