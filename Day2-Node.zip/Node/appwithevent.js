const EventEmitter=require('events');
const Logger=require('./loggerwithevent');
const logger=new Logger();

logger.on('messageLogged',
(arg)=>{
    console.log("Listener is called");
}
);

logger.log('--Logged Message!--');