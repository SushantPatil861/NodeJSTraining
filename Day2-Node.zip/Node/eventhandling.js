const EventEmitter=require('events');
const emitter = new EventEmitter();
const emitter1 = new EventEmitter();
emitter.addListener('messageLogged',function(arg){

    console.log("Listener is Called"+arg);
    console.log("Listener is Called",arg);
});
//we can use 'on' instead of addListener and we can use lamda exp instead of function
emitter1.on('messageLogged',
    (arg)=>{

    console.log("Listener is Called"+arg);
    console.log("Listener is Called",arg);
});
emitter.emit("messageLogged",{id:1,url:'www.google.com'});
emitter1.emit("messageLogged",{id:1,url:'www.google.com'});