const fs = require('fs'); //constants cant be changed later
const files=fs.readdirSync('./');
console.log(files);

console.log('=======================');

fs.readdir('./',function(err,files){
    if(err){
        console.log("Errors Found : "+err);
    }
    console.log(files);
})
