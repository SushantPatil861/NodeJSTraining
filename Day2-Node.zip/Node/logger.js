var url='httP://abc.com'
function log(message){
    console.log(message);
}

module.exports.logFun=log;
module.exports.endPoint=url;