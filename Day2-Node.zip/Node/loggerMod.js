
function logMod(message){
    console.log("Hello"+message);
}


module.exports=logMod;