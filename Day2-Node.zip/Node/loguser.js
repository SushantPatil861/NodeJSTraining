var logger=require('./logger');
logger.logFun(logger.endPoint);

var logger1=require('./loggerMod');
logger1(" Sushant");

console.log(logger);
console.log(logger1);