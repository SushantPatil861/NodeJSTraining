const http=require('http');
const server=http.createServer((req,res)=>{
    if(req.url=='/'){
        res.write("Hello World from node js server!");
        res.end();
    }
    if(req.url=='/api/empData'){
        res.write(JSON.stringify([1,2,3,4,5]));
        res.end();
    }
});
server.listen(3000);
console.log("Server started Successfully on 3000 port");